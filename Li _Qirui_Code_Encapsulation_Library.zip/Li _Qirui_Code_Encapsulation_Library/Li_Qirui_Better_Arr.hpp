#include <bits/stdc++.h>
using namespace std;

struct arr {
    int data[100];
    int data_size=0;
    void print() {
        for (int i = 0; i < this->data_size; i++) {
            cout << this->data[i] << " ";
        }
        cout << endl;
    }
    int& operator [] (int index) {
        return this->data[index];
    }
    void reset() {
        this->data_size = 0;
        memset(this->data,0,sizeof(this->data));
        return;
    }
    void push(int num) {
        this->data[this->data_size] = num;
        this->data_size++;
        return;
    }
};

struct STL {
    string STL_data;
    int STL_size=0;
    void print() {
        for (int i = 0; i < this->STL_size; i++) {
            int temp=this->STL_data[i];
            cout << temp << " ";
        }
        cout << endl;
    }
    void push(int num) {
        this->STL_data[this->STL_size] = num;
        this->STL_size++;
    }
    int pop() {
        this->STL_size--;
        return STL_data[this->STL_size];
    }
    char& operator [] (int index) {
        return this->STL_data[index];
    }
};

class Matrix {
private:
    int rows;
    int cols;
    double** data;

    void allocateMemory();
    void deallocateMemory();
    void copyData(const Matrix& other);

public:
    Matrix(int r = 1, int c = 1, double initialValue = 0.0);
    Matrix(const Matrix& other);
    ~Matrix();
    Matrix& operator=(const Matrix& other);
    Matrix operator+(const Matrix& other) const;
    Matrix operator-(const Matrix& other) const;
    Matrix operator*(const Matrix& other) const;
    Matrix operator*(double scalar) const;
    Matrix& operator+=(const Matrix& other);
    Matrix& operator-=(const Matrix& other);
    Matrix& operator*=(const Matrix& other);
    Matrix& operator*=(double scalar);
    double* operator[](int row);
    const double* operator[](int row) const;
    Matrix transpose() const;
    double determinant() const;
    Matrix inverse() const;
    void resize(int newRows, int newCols);
    void fill(double value);
    int getRows() const;
    int getCols() const;
    void print() const;
};

Matrix operator*(double scalar, const Matrix& matrix);

