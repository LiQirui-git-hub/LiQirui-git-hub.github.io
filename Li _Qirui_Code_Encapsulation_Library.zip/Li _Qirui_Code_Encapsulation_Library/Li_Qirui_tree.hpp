#include <bits/stdc++.h>
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

TreeNode* buildTree_from_preorder_inorder(int* preorder, int* inorder, int preStart, int preEnd, int inStart, int inEnd) {
    if (preStart > preEnd || inStart > inEnd) {
        return nullptr;
    }

    int rootVal = preorder[preStart];
    TreeNode* root = new TreeNode(rootVal);

    int rootIndex = inStart;
    while (rootIndex <= inEnd && inorder[rootIndex] != rootVal) {
        rootIndex++;
    }

    int leftSubtreeSize = rootIndex - inStart;

    root->left = buildTree_from_preorder_inorder(preorder, inorder, 
                          preStart + 1, preStart + leftSubtreeSize, 
                          inStart, rootIndex - 1);
    root->right = buildTree_from_preorder_inorder(preorder, inorder, 
                           preStart + leftSubtreeSize + 1, preEnd, 
                           rootIndex + 1, inEnd);
    
    return root;
}

TreeNode* buildTree_from_inorder_postorder(int* inorder, int* postorder, int inStart, int inEnd, int postStart, int postEnd) {
    if (inStart > inEnd || postStart > postEnd) {
        return nullptr;
    }

    int rootVal = postorder[postEnd];
    TreeNode* root = new TreeNode(rootVal);

    int rootIndex = inStart;
    while (rootIndex <= inEnd && inorder[rootIndex] != rootVal) {
        rootIndex++;
    }

    int leftSubtreeSize = rootIndex - inStart;

    root->left = buildTree_from_inorder_postorder(inorder, postorder, inStart, rootIndex - 1, postStart, postStart + leftSubtreeSize - 1);
                                                
    root->right = buildTree_from_inorder_postorder(inorder, postorder, rootIndex + 1, inEnd, postStart + leftSubtreeSize, postEnd - 1);
                                                 
    return root;
}

TreeNode* buildTree_from_levelorder(vector<int>& levelorder) {
    if (levelorder.empty()) {
        return nullptr;
    }

    TreeNode* root = new TreeNode(levelorder[0]);
    queue<TreeNode*> q;
    q.push(root);
    
    int index = 1;
    while (!q.empty() && index < levelorder.size()) {
        TreeNode* curr = q.front();
        q.pop();
        if (index < levelorder.size() && levelorder[index] != -1) {
            curr->left = new TreeNode(levelorder[index]);
            q.push(curr->left);
        }
        index++;
        if (index < levelorder.size() && levelorder[index] != -1) {
            curr->right = new TreeNode(levelorder[index]);
            q.push(curr->right);
        }
        index++;
    }
    return root;
}

void preorderTraversal(TreeNode* root) {
    if (root == nullptr) return;
    printf("%c",root->val);
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

void inorderTraversal(TreeNode* root) {
    if (root == nullptr) return;
    inorderTraversal(root->left);
    printf("%c",root->val);
    inorderTraversal(root->right);
}

void postorderTraversal(TreeNode* root) {
    if (root == nullptr) return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    printf("%c",root->val);
}

void LevelorderTraversal(TreeNode* root) {
    if (root == nullptr) return;
    queue<TreeNode*> que;
    que.push(root);
    while(!que.empty()){
    	TreeNode* fr_data=que.front();
    	printf("%c",fr_data->val);
    	que.pop();
    	if(fr_data->left!=nullptr) que.push(fr_data->left);
    	if(fr_data->right!=nullptr) que.push(fr_data->right);
	}
}

void deleteTree(TreeNode* root) {
    if (root == nullptr) return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}
