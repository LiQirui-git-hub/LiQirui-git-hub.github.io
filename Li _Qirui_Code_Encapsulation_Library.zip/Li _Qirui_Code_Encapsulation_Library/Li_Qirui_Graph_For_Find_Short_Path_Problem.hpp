#include<bits/stdc++.h>
using namespace std;

struct Graph {
    int** adj;
    int* size;
    bool* isObstacle;
    int vertexCount;
    int rows;
    int cols;
};

Graph* initGraph(int rows, int cols) {
    Graph* graph = new Graph;
    graph->rows = rows;
    graph->cols = cols;
    graph->vertexCount = rows * cols;
    graph->adj = new int*[graph->vertexCount];
    graph->size = new int[graph->vertexCount];
    graph->isObstacle = new bool[graph->vertexCount];
    for (int i = 0; i < graph->vertexCount; i++) {
        graph->adj[i] = nullptr;
        graph->size[i] = 0;
        graph->isObstacle[i] = false;
    }
    return graph;
}

void addEdge(Graph* graph, int from, int to) {
    if (from < 0 || from >= graph->vertexCount || to < 0 || to >= graph->vertexCount || from == to) return;
    for (int i = 0; i < graph->size[from]; i++) {
        if (graph->adj[from][i] == to) return;
    }
    int* newAdj = new int[graph->size[from] + 1];
    for (int i = 0; i < graph->size[from]; i++) newAdj[i] = graph->adj[from][i];
    newAdj[graph->size[from]] = to;
    delete[] graph->adj[from];
    graph->adj[from] = newAdj;
    graph->size[from]++;
    newAdj = new int[graph->size[to] + 1];
    for (int i = 0; i < graph->size[to]; i++) newAdj[i] = graph->adj[to][i];
    newAdj[graph->size[to]] = from;
    delete[] graph->adj[to];
    graph->adj[to] = newAdj;
    graph->size[to]++;
}

void generateGrid(Graph* graph) {
    if (graph == nullptr || graph->rows <= 0 || graph->cols <= 0) return;
    for (int r = 0; r < graph->rows; r++) {
        for (int c = 0; c < graph->cols; c++) {
            int current = r * graph->cols + c;
            if (r > 0) addEdge(graph, current, (r - 1) * graph->cols + c);
            if (r < graph->rows - 1) addEdge(graph, current, (r + 1) * graph->cols + c);
            if (c > 0) addEdge(graph, current, r * graph->cols + (c - 1));
            if (c < graph->cols - 1) addEdge(graph, current, r * graph->cols + (c + 1));
        }
    }
}

int toIndex(Graph* graph, int row, int col) {
    if (graph == nullptr || row < 0 || row >= graph->rows || col < 0 || col >= graph->cols) return -1;
    return row * graph->cols + col;
}

int getRow(Graph* graph, int index) {
    if (graph == nullptr || index < 0 || index >= graph->vertexCount) return -1;
    return index / graph->cols;
}

int getCol(Graph* graph, int index) {
    if (graph == nullptr || index < 0 || index >= graph->vertexCount) return -1;
    return index % graph->cols;
}

void setObstacle(Graph* graph, int vertex) {
    if (vertex >= 0 && vertex < graph->vertexCount) graph->isObstacle[vertex] = true;
}

void setObstacle(Graph* graph, int row, int col) {
    int vertex = toIndex(graph, row, col);
    setObstacle(graph, vertex);
}

int bfsShortestPath(Graph* graph, int start, int target, int*& path, int& pathLength) {
    if (graph == nullptr || start < 0 || start >= graph->vertexCount || target < 0 || target >= graph->vertexCount) {
        path = nullptr;
        pathLength = 0;
        return -1;
    }
    if (start == target) {
        pathLength = 1;
        path = new int[1];
        path[0] = start;
        return 0;
    }
    if (graph->isObstacle[start] || graph->isObstacle[target]) {
        path = nullptr;
        pathLength = 0;
        return -1;
    }
    bool* visited = new bool[graph->vertexCount];
    int* distance = new int[graph->vertexCount];
    int* predecessor = new int[graph->vertexCount];
    memset(visited, 0, graph->vertexCount * sizeof(bool));
    memset(distance, -1, graph->vertexCount * sizeof(int));
    memset(predecessor, -1, graph->vertexCount * sizeof(int));
    queue<int> q;
    q.push(start);
    visited[start] = true;
    distance[start] = 0;
    while (!q.empty()) {
        int current = q.front();
        q.pop();
        if (current == target) break;
        for (int i = 0; i < graph->size[current]; i++) {
            int neighbor = graph->adj[current][i];
            if (!visited[neighbor] && !graph->isObstacle[neighbor]) {
                visited[neighbor] = true;
                distance[neighbor] = distance[current] + 1;
                predecessor[neighbor] = current;
                q.push(neighbor);
            }
        }
    }
    int shortestDistance = distance[target];
    if (shortestDistance != -1) {
        pathLength = 0;
        int temp = target;
        while (temp != -1) {
            pathLength++;
            temp = predecessor[temp];
        }
        path = new int[pathLength];
        temp = target;
        for (int i = pathLength - 1; i >= 0; i--) {
            path[i] = temp;
            temp = predecessor[temp];
        }
    } else {
        path = nullptr;
        pathLength = 0;
    }
    delete[] visited;
    delete[] distance;
    delete[] predecessor;
    return shortestDistance;
}

void printGrid(Graph* graph) {
    if (graph == nullptr) return;
    cout << "����ͼչʾ (O: ����, X: �ϰ�):" << endl;
    for (int r = 0; r < graph->rows; r++) {
        for (int c = 0; c < graph->cols; c++) {
            int idx = toIndex(graph, r, c);
            if (graph->isObstacle[idx]) cout << "X ";
            else cout << "O ";
        }
        cout << endl;
    }
}

void freeGraph(Graph* graph) {
    if (graph == nullptr) return;
    for (int i = 0; i < graph->vertexCount; i++) delete[] graph->adj[i];
    delete[] graph->adj;
    delete[] graph->size;
    delete[] graph->isObstacle;
    delete graph;
}
