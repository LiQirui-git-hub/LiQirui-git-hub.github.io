#include <bits/stdc++.h>
using namespace std;

struct BigInteger {
	private:
		deque<int> num;
		bool sgn;
		
	public:
		BigInteger operator = (long long init) {
			num.clear();
			if (init) {
				if (init > 0) sgn = true;
				else {
					sgn = false;
					init = -init;
				}
				while (init) {
					num.push_front(init % 10);
					init /= 10;
				}
			} else {
				sgn = true;
				num.push_back(0);
			}
			return *this;
		}
		
		BigInteger operator = (int init) { return (*this = (long long) init); }
		
		BigInteger operator = (const char *s) {
			num.clear();
			assert(*s);
			if (*s == '-') {
				sgn = false;
				assert(*(++s));
			} else sgn = true;
			while (*s) {
				assert(isdigit(*s));
				num.push_back(*(s++) - '0');
			}
			if (num.size() >= 2) assert(num[0]);
			assert(sgn || num[0]);
			return *this;
		}
		
		BigInteger() { *this = 0LL; }
		BigInteger(int init) { *this = init; }
		BigInteger(long long init) { *this = init; } 
		BigInteger(const char *s) { *this = s; }
		BigInteger(string s) { *this = s.c_str(); }
		
		BigInteger operator - () {
			if (num[0] == 0) return *this;
			BigInteger ret = *this;
			ret.sgn = !ret.sgn;
			return ret;
		}
		
		bool operator < (const BigInteger &rhs) const {
			if (sgn != rhs.sgn) return !sgn;
			if (num.size() < rhs.num.size()) return sgn;
			if (num.size() > rhs.num.size()) return !sgn;
			for (int i = 0; i < num.size(); i++)
				if (num[i] != rhs.num[i])
					return (sgn ? (num[i] < rhs.num[i]) : (num[i] > rhs.num[i]));
			return false;
		}
		bool operator < (int rhs) const { return *this < BigInteger(rhs); }
		bool operator < (long long rhs) const { return *this < BigInteger(rhs); }
		bool operator < (const char *rhs) const { return *this < BigInteger(rhs); }
		bool operator < (string rhs) const { return *this < BigInteger(rhs); }
		
		bool operator > (const BigInteger &rhs) const { return rhs < *this; }
		bool operator > (int rhs) const { return *this > BigInteger(rhs); }
		bool operator > (long long rhs) const { return *this > BigInteger(rhs); }
		bool operator > (const char *rhs) const { return *this > BigInteger(rhs); }
		bool operator > (string rhs) const { return *this > BigInteger(rhs); }
		
		bool operator <= (const BigInteger &rhs) const { return !(*this > rhs); }
		bool operator <= (int rhs) const { return *this <= BigInteger(rhs); }
		bool operator <= (long long rhs) const { return *this <= BigInteger(rhs); }
		bool operator <= (const char *rhs) const { return *this <= BigInteger(rhs); }
		bool operator <= (string rhs) const { return *this <= BigInteger(rhs); }
		
		bool operator >= (const BigInteger &rhs) const { return !(*this < rhs); }
		bool operator >= (int rhs) const { return *this >= BigInteger(rhs); }
		bool operator >= (long long rhs) const { return *this >= BigInteger(rhs); }
		bool operator >= (const char *rhs) const { return *this >= BigInteger(rhs); }
		bool operator >= (string rhs) const { return *this >= BigInteger(rhs); }
		
		bool operator == (const BigInteger &rhs) const { return !(*this < rhs) && !(*this > rhs); }
		bool operator == (int rhs) const { return *this == BigInteger(rhs); }
		bool operator == (long long rhs) const { return *this == BigInteger(rhs); }
		bool operator == (const char *rhs) const { return *this == BigInteger(rhs); }
		bool operator == (string rhs) const { return *this == BigInteger(rhs); }
		
		bool operator != (const BigInteger &rhs) const { return !(*this == rhs); }
		bool operator != (int rhs) const { return *this != BigInteger(rhs); }
		bool operator != (long long rhs) const { return *this != BigInteger(rhs); }
		bool operator != (const char *rhs) const { return *this != BigInteger(rhs); }
		bool operator != (string rhs) const { return *this != BigInteger(rhs); }
		
		operator bool() {
			return num[0];
		}
		
		operator string() {
			string ret;
			if (!sgn) ret += "-";
			for (int i = 0; i < num.size(); i++) {
				ret += num[i] + '0';
			}
			return ret;
		}
		
		operator int() {
			int ret = 0;
			for (int i = 0; i < num.size(); i++) ret = ret * 10 + num[i];
			return ret;
		}
		
		operator long long() {
			long long ret = 0;
			for (int i = 0; i < num.size(); i++) ret = ret * 10 + num[i];
			return ret;
		}
		
		friend istream& operator >> (istream &in, BigInteger &lhs) {
			string init;
			in >> init;
			lhs = init;
			return in;
		}
		
		friend ostream& operator << (ostream &out, BigInteger lhs) {
			out << (string) lhs;
			return out;
		}
		
		friend BigInteger operator + (BigInteger, BigInteger);
		friend BigInteger operator - (BigInteger, BigInteger);
		friend BigInteger operator * (BigInteger, BigInteger);
		friend BigInteger operator / (BigInteger, BigInteger);
		friend BigInteger operator % (BigInteger, BigInteger);
		
		friend BigInteger operator + (BigInteger lhs, int rhs) { return lhs + BigInteger(rhs); }
		friend BigInteger operator + (BigInteger lhs, long long rhs) { return lhs + BigInteger(rhs); }
		friend BigInteger operator + (BigInteger lhs, const char *rhs) { return lhs + BigInteger(rhs); }
		friend BigInteger operator + (BigInteger lhs, string rhs) { return lhs + BigInteger(rhs); }
		friend BigInteger operator + (int lhs, BigInteger rhs) { return BigInteger(lhs) + rhs; }
		friend BigInteger operator + (long long lhs, BigInteger rhs) { return BigInteger(lhs) + rhs; }
		friend BigInteger operator + (const char *lhs, BigInteger rhs) { return BigInteger(lhs) + rhs; }
		friend BigInteger operator + (string lhs, BigInteger rhs) { return BigInteger(lhs) + rhs; }
		
		friend BigInteger operator - (BigInteger lhs, int rhs) { return lhs - BigInteger(rhs); }
		friend BigInteger operator - (BigInteger lhs, long long rhs) { return lhs - BigInteger(rhs); }
		friend BigInteger operator - (BigInteger lhs, const char *rhs) { return lhs - BigInteger(rhs); }
		friend BigInteger operator - (BigInteger lhs, string rhs) { return lhs - BigInteger(rhs); }
		friend BigInteger operator - (int lhs, BigInteger rhs) { return BigInteger(lhs) - rhs; }
		friend BigInteger operator - (long long lhs, BigInteger rhs) { return BigInteger(lhs) - rhs; }
		friend BigInteger operator - (const char *lhs, BigInteger rhs) { return BigInteger(lhs) - rhs; }
		friend BigInteger operator - (string lhs, BigInteger rhs) { return BigInteger(lhs) - rhs; }
		
		friend BigInteger operator * (BigInteger lhs, int rhs) { return lhs * BigInteger(rhs); }
		friend BigInteger operator * (BigInteger lhs, long long rhs) { return lhs * BigInteger(rhs); }
		friend BigInteger operator * (BigInteger lhs, const char *rhs) { return lhs * BigInteger(rhs); }
		friend BigInteger operator * (BigInteger lhs, string rhs) { return lhs * BigInteger(rhs); }
		friend BigInteger operator * (int lhs, BigInteger rhs) { return BigInteger(lhs) * rhs; }
		friend BigInteger operator * (long long lhs, BigInteger rhs) { return BigInteger(lhs) * rhs; }
		friend BigInteger operator * (const char *lhs, BigInteger rhs) { return BigInteger(lhs) * rhs; }
		friend BigInteger operator * (string lhs, BigInteger rhs) { return BigInteger(lhs) * rhs; }
		
		friend BigInteger operator / (BigInteger lhs, int rhs) { return lhs / BigInteger(rhs); }
		friend BigInteger operator / (BigInteger lhs, long long rhs) { return lhs / BigInteger(rhs); }
		friend BigInteger operator / (BigInteger lhs, const char *rhs) { return lhs / BigInteger(rhs); }
		friend BigInteger operator / (BigInteger lhs, string rhs) { return lhs / BigInteger(rhs); }
		friend BigInteger operator / (int lhs, BigInteger rhs) { return BigInteger(lhs) / rhs; }
		friend BigInteger operator / (long long lhs, BigInteger rhs) { return BigInteger(lhs) / rhs; }
		friend BigInteger operator / (const char *lhs, BigInteger rhs) { return BigInteger(lhs) / rhs; }
		friend BigInteger operator / (string lhs, BigInteger rhs) { return BigInteger(lhs) / rhs; }
		
		friend BigInteger operator % (BigInteger lhs, int rhs) { return lhs % BigInteger(rhs); }
		friend BigInteger operator % (BigInteger lhs, long long rhs) { return lhs % BigInteger(rhs); }
		friend BigInteger operator % (BigInteger lhs, const char *rhs) { return lhs % BigInteger(rhs); }
		friend BigInteger operator % (BigInteger lhs, string rhs) { return lhs % BigInteger(rhs); }
		friend BigInteger operator % (int lhs, BigInteger rhs) { return BigInteger(lhs) % rhs; }
		friend BigInteger operator % (long long lhs, BigInteger rhs) { return BigInteger(lhs) % rhs; }
		friend BigInteger operator % (const char *lhs, BigInteger rhs) { return BigInteger(lhs) % rhs; }
		friend BigInteger operator % (string lhs, BigInteger rhs) { return BigInteger(lhs) % rhs; }
		
		BigInteger & operator += (BigInteger rhs) {
			*this = *this + rhs;
			return *this;
		}
		BigInteger & operator += (int rhs) {
			*this = *this + BigInteger(rhs);
			return *this;
		}
		BigInteger & operator += (long long rhs) {
			*this = *this + BigInteger(rhs);
			return *this;
		}
		BigInteger & operator += (const char *rhs) {
			*this = *this + BigInteger(rhs);
			return *this;
		}
		BigInteger & operator += (string rhs) {
			*this = *this + BigInteger(rhs);
			return *this;
		}
		
		BigInteger & operator -= (BigInteger rhs) {
			*this = *this - rhs;
			return *this;
		}
		BigInteger & operator -= (int rhs) {
			*this = *this - BigInteger(rhs);
			return *this;
		}
		BigInteger & operator -= (long long rhs) {
			*this = *this - BigInteger(rhs);
			return *this;
		}
		BigInteger & operator -= (const char *rhs) {
			*this = *this - BigInteger(rhs);
			return *this;
		}
		BigInteger & operator -= (string rhs) {
			*this = *this - BigInteger(rhs);
			return *this;
		}
		// 233333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333
		BigInteger & operator *= (BigInteger rhs) {
			*this = *this * BigInteger(rhs);
			return *this;
		}
		BigInteger & operator *= (int rhs) {
			*this = *this * BigInteger(rhs);
			return *this;
		}
		BigInteger & operator *= (long long rhs) {
			*this = *this * BigInteger(rhs);
			return *this;
		}
		BigInteger & operator *= (const char *rhs) {
			*this = *this * BigInteger(rhs);
			return *this;
		}
		BigInteger & operator *= (string rhs) {
			*this = *this * BigInteger(rhs);
			return *this;
		}
		
		BigInteger & operator /= (BigInteger rhs) {
			*this = *this / rhs;
			return *this;
		}
		BigInteger & operator /= (int rhs) {
			*this = *this / BigInteger(rhs);
			return *this;
		}
		BigInteger & operator /= (long long rhs) {
			*this = *this / BigInteger(rhs);
			return *this;
		}
		BigInteger & operator /= (const char *rhs) {
			*this = *this / BigInteger(rhs);
			return *this;
		}
		BigInteger & operator /= (string rhs) {
			*this = *this / BigInteger(rhs);
			return *this;
		}
		
		BigInteger & operator %= (BigInteger rhs) {
			*this = *this % BigInteger(rhs);
			return *this;
		}
		BigInteger & operator %= (int rhs) {
			*this = *this % BigInteger(rhs);
			return *this;
		}
		BigInteger & operator %= (long long rhs) {
			*this = *this % BigInteger(rhs);
			return *this;
		}
		BigInteger & operator %= (const char *rhs) {
			*this = *this % BigInteger(rhs);
			return *this;
		}
		BigInteger & operator %= (string rhs) {
			*this = *this % BigInteger(rhs);
			return *this;
		}
		
		BigInteger & operator ++ () {
			*this += BigInteger(1);
			return *this;
		}
		
		BigInteger operator ++ (int _) {
			BigInteger tmp(*this);
			*this += BigInteger(1);
			return tmp;
		}
		
		BigInteger & operator -- () {
			*this -= BigInteger(1);
			return *this;
		}
		
		BigInteger operator -- (int _) {
			BigInteger tmp(*this);
			*this -= BigInteger(1);
			return tmp;
		}
		
		BigInteger pow(BigInteger n) {
			assert(*this);
			assert(n >= 0);
			if (n == BigInteger(0)) return BigInteger(1);
			BigInteger res = pow(n / BigInteger(2));
			if (n % BigInteger(2)) return res * res * (*this);
			return res * res;
		}
		BigInteger pow(int n) { return pow(BigInteger(n)); }
		BigInteger pow(long long n) { return pow(BigInteger(n)); }
		BigInteger pow(const char *n) { return pow(BigInteger(n)); }
		BigInteger pow(string n) { return pow(BigInteger(n)); }
};

BigInteger operator + (BigInteger lhs, BigInteger rhs) {
	if (lhs.sgn && !rhs.sgn) {
		rhs.sgn = true;
		return lhs - rhs;
	}
	if (!lhs.sgn && rhs.sgn) {
		lhs.sgn = true;
		return rhs - lhs;
	}
	if (lhs.num.size() < rhs.num.size()) swap(lhs, rhs);
	for (int i = 0; i < rhs.num.size(); i++)
		lhs.num[lhs.num.size() - rhs.num.size() + i] += rhs.num[i];
	for (int i = lhs.num.size() - 1; i > 0; i--) {
		lhs.num[i - 1] += lhs.num[i] / 10;
		lhs.num[i] %= 10;
	}
	if (lhs.num[0] >= 10) {
		lhs.num.push_front(lhs.num[0] / 10);
		lhs.num[1] %= 10;
	}
	return lhs;
}

BigInteger operator - (BigInteger lhs, BigInteger rhs) {
	if (lhs.sgn && !rhs.sgn) {
		rhs.sgn = true;
		return lhs + rhs;
	}
	if (!lhs.sgn && rhs.sgn) return lhs + rhs;
	if (!lhs.sgn && !rhs.sgn) {
		lhs.sgn = true;
		rhs.sgn = true;
		return rhs - lhs;
	}
	if (lhs < rhs) return -(rhs - lhs);
	for (int i = lhs.num.size() - rhs.num.size(); i < lhs.num.size(); i++) 
		lhs.num[i] -= rhs.num[rhs.num.size() + i - lhs.num.size()];
	for (int i = lhs.num.size() - 1; i > 0; i--) {
		while (lhs.num[i] < 0) {
			lhs.num[i - 1]--;
			lhs.num[i] += 10;
		}
	}
	while (lhs.num.size() >= 2 && lhs.num[0] == 0) lhs.num.pop_front();
	return lhs;
}

BigInteger operator * (BigInteger lhs, BigInteger rhs) {
	deque<int> mul(lhs.num.size() + rhs.num.size(), 0);
	reverse(lhs.num.begin(), lhs.num.end());
	reverse(rhs.num.begin(), rhs.num.end());
	for (int i = 0; i < lhs.num.size(); i++)
		for (int j = 0; j < rhs.num.size(); j++)
			mul[i + j] += lhs.num[i] * rhs.num[j];
	for (int i = 0; i < mul.size() - 1; i++) {
		mul[i + 1] += mul[i] / 10;
		mul[i] %= 10;
	}
	if (mul[mul.size() - 1]) {
		mul.push_back(mul[mul.size() - 1] / 10);
		mul[mul.size() - 2] %= 10;
	}
    while (mul.size() >= 2 && mul[mul.size() - 1] == 0) mul.pop_back();
	reverse(mul.begin(), mul.end());
	lhs.sgn = (lhs.sgn ^ rhs.sgn ^ 1);
	lhs.num = mul;
	return lhs;
}

BigInteger operator / (BigInteger lhs, BigInteger rhs) {
	assert(rhs);
	BigInteger ret, cnt, div;
	bool sgn = (lhs.sgn ^ rhs.sgn ^ 1);
	rhs.sgn = true;
	div.num.clear();
	for (int i = 0; i < lhs.num.size(); i++) {
		while (!div.num.empty() && div.num[0] == 0) div.num.pop_front();
		div.num.push_back(lhs.num[i]);
		cnt = 0;
		while (div > rhs) {
			div -= rhs;
			cnt++;
		}
		if (div == rhs) {
			div = 0;
			cnt++;
		}
		ret = ret * BigInteger(10) + cnt;
	}
	ret.sgn = sgn;
	return ret; 
}

BigInteger operator % (BigInteger lhs, BigInteger rhs) {
	return lhs - lhs / rhs * rhs;
}

typedef BigInteger BigInt;

